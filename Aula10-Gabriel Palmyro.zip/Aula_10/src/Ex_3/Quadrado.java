package Ex_3;

public class Quadrado {
	
	private double lado;
	
	public Quadrado()
	{
		
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}
	
	double calcularArea()
	{
		double area = (this.lado * this.lado);
		return area;
	}
}
