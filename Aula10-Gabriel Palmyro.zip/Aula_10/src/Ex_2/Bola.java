package Ex_2;

public class Bola {
	
	private String cor;
	private double circunferencia;
	private String material;
	
	public Bola()
	{
		
	}
	
	public Bola(String cor, double circu, String material)
	{
		this.cor = cor;
		this.circunferencia = circu;
		this.material = material;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public double getCircunferencia() {
		return circunferencia;
	}

	public void setCircunferencia(double circunferencia) {
		this.circunferencia = circunferencia;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}
	
	

}
