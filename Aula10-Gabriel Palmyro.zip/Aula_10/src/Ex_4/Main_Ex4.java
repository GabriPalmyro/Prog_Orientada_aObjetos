package Ex_4;

public class Main_Ex4 {

	public static void main(String[] args) {
	
		Aluno alu1 = new Aluno();
		
		alu1.setMatricula("10010");
		alu1.setNota1(7.5);
		alu1.setNota2(8.0);
		
		System.out.printf("%s e m�dia %.2f", alu1.imprimirDados(), alu1.calcMedia());
		
	}

}
