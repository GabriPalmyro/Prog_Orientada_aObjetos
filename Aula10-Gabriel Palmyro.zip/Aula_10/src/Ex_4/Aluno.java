package Ex_4;

public class Aluno {

	private String matricula;
	private double nota1, nota2;
	
	public Aluno()
	{
		
	}
	
	public Aluno(String matricula, double nota1, double nota2)
	{
		this.matricula = matricula;
		this.nota1 = nota1;
		this.nota2 = nota2;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public double getNota1() {
		return nota1;
	}

	public void setNota1(double nota1) {
		this.nota1 = nota1;
	}

	public double getNota2() {
		return nota2;
	}

	public void setNota2(double nota2) {
		this.nota2 = nota2;
	}
	
	String imprimirDados()
	{
		String texto = "";
		
		texto = "O aluno de matricula "
		+this.matricula+" possui nota 1 = "
		+this.nota1+" e nota 2 = "
		+this.nota2;
		
		return texto;
	}
	
	double calcMedia()
	{
		double media;
		media = (nota1+nota2)/2;
		return media;
	}
}
