package Ex_8;

public class Calculadora {

	public double soma(double a, double b)
	{
		double soma = a + b;
		return soma;
	}
	
	public double subt(double a, double b)
	{
		double sub = b - a;
		return sub;
	}
	
	public double divi(double a, double b)
	{
		double divisao = a / b;
		return divisao;
	}
	
	public double mult(double a, double b)
	{
		double mult = a * b;
		return mult;
	}
	
}
