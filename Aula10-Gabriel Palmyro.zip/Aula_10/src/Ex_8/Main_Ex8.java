package Ex_8;

import java.util.Scanner;

public class Main_Ex8 {

	public static void main(String[] args) {
		
		 Scanner ler = new Scanner(System.in);
	        
	        int op1 = 1;
	        double a, b;
	        Calculadora Calculadora = new Calculadora();

	        while(op1 != 5){
	            System.out.println("MENU\n1-Soma\n2-Subtra��o\n3-Multiplica��o\n4-Divis�o\n5-Sair");
	            op1 = ler.nextInt();
	            switch(op1){
	                case 1:
	                    System.out.println("Soma!\nEntre com os numeros a serem somados: ");
	                    a = ler.nextDouble();
	                    b = ler.nextDouble();
	                    System.out.println("Deseja ver o resultado? (1(S)/0(N))");

	                    System.out.printf("%.2f\n",Calculadora.soma(a,b));
	                    break;
	                case 2:
	                    System.out.println("Subtra��o!\nEntre com os numeros a serem subtra�dos: ");
	                    a = ler.nextDouble();
	                    b = ler.nextDouble();
	                    System.out.println("Deseja ver o resultado? (1(S)/0(N))");

	                    System.out.printf("%.2f\n" ,Calculadora.subt(a,b));
	                    break;
	                case 4:
	                    System.out.println("Divis�o!\nEntre com os numeros a serem divididos: ");
	                    a = ler.nextDouble();
	                    b = ler.nextDouble();
	                    System.out.println("Deseja ver o resultado? (1(S)/0(N))");

	                    System.out.printf("%.2f\n" ,Calculadora.divi(a,b));
	                    break;
	                case 3:
	                    System.out.println("Multiplica��o!\nEntre com os numeros a serem multiplicados: ");
	                    a = ler.nextDouble();
	                    b = ler.nextDouble();
	                    System.out.println("Deseja ver o resultado? (1(S)/0(N))");

	                    System.out.println(Calculadora.mult(a,b));
	                    break;
	                case 5:
	                    break;  
	            }
	        }

	        ler.close();


	}

}
