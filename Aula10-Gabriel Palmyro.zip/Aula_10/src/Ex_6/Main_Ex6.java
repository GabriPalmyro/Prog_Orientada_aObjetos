package Ex_6;

import java.util.Scanner;

public class Main_Ex6 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Circulo circ = new Circulo();
		
		double raio;
		
		System.out.println("Entre com o raio do circulo: ");
		raio = ler.nextInt();
		
		circ.setRaio(raio);
		
		circ.calcularArea();
		circ.calcularPerimetro();
		
		circ.imprimirDado();
		
		ler.close();
	}

}
