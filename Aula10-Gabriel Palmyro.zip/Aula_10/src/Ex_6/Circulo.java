package Ex_6;

public class Circulo {
	
	private double raio, area, perimetro;
	
	public Circulo()
	{
		
	}
	
	public Circulo(double raio)
	{
		this.raio = raio;
	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public double getPerimetro() {
		return perimetro;
	}

	public void setPerimetro(double perimetro) {
		this.perimetro = perimetro;
	}
	
	void calcularArea()
	{
		this.area = (3.141516 * raio * raio);
	}
	
	void calcularPerimetro()
	{
		this.perimetro = (3.141516 * raio * 2);
	}
	
	void imprimirDado()
	{
		System.out.printf("O circulo de raio %.2f tem �rea %.2f e perimetro de %.2f\n", raio, area, perimetro);
	}
}

