package Ex_5;

import java.util.Scanner;


public class Main_Ex5 {
	
	static int aposentar(Funcionario func)
	{
		if(func.getIdade() > 60 && func.getAnosServico() >= 35)
		{
			return 1;
		} else { return 0; }
		
	}

	public static void main(String[] args) {
	
		Scanner ler = new Scanner(System.in);
		
		int idade, anosS;
		double salario;
		
		Funcionario func1 = new Funcionario();
		Funcionario func2 = new Funcionario();
		
		System.out.println("Entre com a idade do funcionario 1: ");
		idade = ler.nextInt();
		func1.setIdade(idade);
		System.out.println("Entre com os anos de servi�o do funcionario 1: ");
		anosS = ler.nextInt();
		func1.setAnosServico(anosS);
		System.out.println("Entre com o sal�rio do funcionario 1: ");
		salario = ler.nextDouble();
		func1.setSalario(salario);
		
		System.out.println("Entre com a idade do funcionario 2: ");
		idade = ler.nextInt();
		func2.setIdade(idade);
		System.out.println("Entre com os anos de servi�o do funcionario 2: ");
		anosS = ler.nextInt();
		func2.setAnosServico(anosS);
		System.out.println("Entre com o sal�rio do funcionario 2: ");
		salario = ler.nextDouble();
		func2.setSalario(salario);
		
		if(aposentar(func1) == 1) System.out.printf("O funcion�rio 1 pode se aposentar\n");
		else System.out.printf("O funcion�rio 1 n�o pode se aposentar ainda\n");
		
		if(aposentar(func2) == 1) System.out.printf("O funcion�rio 2 pode se aposentar\n");
		else System.out.printf("O funcion�rio 2 n�o pode se aposentar ainda\n");
		
		ler.close();
		
	}

}
