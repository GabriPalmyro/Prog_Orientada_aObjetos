package Ex_5;

public class Funcionario {
	
	private int idade;
	private int anosServico;
	private double salario;
	
	public Funcionario()
	{
		
	}
	
	public Funcionario(int idade, int anosS, double salario)
	{
		this.idade = idade;
		this.anosServico = anosS;
		this.salario = salario;
	}
	
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public int getAnosServico() {
		return anosServico;
	}
	public void setAnosServico(int anosServico) {
		this.anosServico = anosServico;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}

}
