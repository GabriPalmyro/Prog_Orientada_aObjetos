package Ex_7;

import java.util.Scanner;

public class Main_Ex7 {
	
	static void MaisCaro(Livro livro1, Livro livro2)
	{
		if(livro1.getPreco() > livro2.getPreco())
		{
			System.out.printf("O livro mais caro � %s com cod %d", livro1.getTitulo(), livro1.getCod());
		} else
		{
			System.out.printf("O livro mais caro � %s com cod %d", livro2.getTitulo(), livro2.getCod());
		}
	}

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		
		Livro harryPotter = new Livro(278, "Harry Potter", "Bloomsbury", 2001, 35.5);
		Livro percyJackson = new Livro();
		
		percyJackson.setCod(310);
		percyJackson.setTitulo("Percy Jackson");
		percyJackson.setEditora("Miramax");
		percyJackson.setAno(2008);
		percyJackson.setPreco(30.0);
		
		MaisCaro(harryPotter, percyJackson);
		
		ler.close();

	}

}
