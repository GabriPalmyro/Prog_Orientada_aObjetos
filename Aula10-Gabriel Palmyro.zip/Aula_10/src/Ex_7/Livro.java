package Ex_7;

public class Livro {
	
	private int cod;
	private String titulo;
	private int ano;
	private String editora;
	private double preco;
	
	public Livro()
	{
		
	}
	
	public Livro(int cod, String tit, String edit, int ano, double preco)
	{
		this.cod = cod;
		this.titulo = tit;
		this.editora = edit;
		this.ano = ano;
		this.preco = preco;
	}

	public int getCod() {
		return cod;
	}

	public void setCod(int cod) {
		this.cod = cod;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getEditora() {
		return editora;
	}

	public void setEditora(String editora) {
		this.editora = editora;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	
	
}
