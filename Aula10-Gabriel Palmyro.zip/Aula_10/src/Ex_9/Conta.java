package Ex_9;

public class Conta {

	private int numConta;
	private String nome;
	private int tipo; //0 - poupan�a | 1 - corrente
	private double saldo;
	
	public Conta()
	{
		this.saldo = 0;
	}
	
	public Conta(int numC, String nome, int tipo)
	{
		this.numConta = numC;
		this.nome = nome;
		this.tipo = tipo;
		this.saldo = 0;
	}

	public int getNumConta() {
		return numConta;
	}

	public void setNumConta(int numConta) {
		this.numConta = numConta;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	void Depositar(double valor)
	{
		this.saldo = saldo + valor;
	}
	
	void Sacar(double valor)
	{
		this.saldo = saldo - valor;
	}
	
	String contaInfos()
	{
		String texto = "";
		texto = "O cliente "
		+nome+" de n�mero de conta "
		+numConta+" possui saldo de R$ "
		+saldo;
		return texto;
	}
	
}
