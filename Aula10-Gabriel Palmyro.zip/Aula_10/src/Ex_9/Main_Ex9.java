package Ex_9;

import java.util.Scanner;

public class Main_Ex9 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);

		int op1 = 1;
		Conta Gabriel = new Conta();
		
		while(op1 != 6){
            System.out.println("MENU\n1-Criar conta\n2-Realizar Deposito\n3-Realizar saque\n4-Mostrar saldo\n5-Mostrar informa��es do titular\n6-Sair");
            op1 = ler.nextInt();
            switch(op1){
                case 1:
                    System.out.println("Entre com numero da conta: ");
                    Gabriel.setNumConta(ler.nextInt());
                    System.out.println("Entre com nome do titular da conta: ");
                    Gabriel.setNome(ler.next());
                    System.out.println("Entre com o tipo da conta: ");
                    Gabriel.setTipo(ler.nextInt());
                    break;
                case 2:
                    Gabriel.Depositar(ler.nextDouble());
                    break;
                case 3:
                    Gabriel.Sacar(ler.nextDouble());
                    break;
                case 4:
                	System.out.println("R$"+Gabriel.getSaldo());
                    break;
                case 5:
                	System.out.println(Gabriel.contaInfos());
                    break; 
                case 6:
                	break;
            }
        }
		
		ler.close();

	}

}
