package Ex3;

public class Normal extends Ingresso {

	public void imprimeValor()
	{
		System.out.printf("Ingresso tipo normal - R$%.2f\n", this.getValor());
	}
	
}
