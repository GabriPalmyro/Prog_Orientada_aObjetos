package Ex3;

public class VIP extends Ingresso { 

	private double adicional = 10.0;

	public double getAdicional() {
		return adicional;
	}

	public void setAdicional(double adicional) {
		this.adicional = adicional;
	}
	
	public void imprimeVIP()
	{
		System.out.printf("Ingresso tipo VIP -  %.2f\n", (this.getValor() + adicional));
	}
	
}
