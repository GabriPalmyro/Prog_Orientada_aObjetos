package Ex3;

public class Ingresso {
	
	private double valor = 50.0;
	
	public void imprimeValor()
	{
		System.out.printf("O valor do ingresso � de %.2f\n", this.valor);
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
}
