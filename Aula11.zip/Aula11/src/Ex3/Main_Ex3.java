package Ex3;

import java.util.Scanner;

public class Main_Ex3 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);

		VIP IngVip = new VIP();
		Normal IngNormal = new Normal();
		
		IngNormal.imprimeValor();
		IngVip.imprimeVIP();
		
		
		ler.close();
		
	}

}
