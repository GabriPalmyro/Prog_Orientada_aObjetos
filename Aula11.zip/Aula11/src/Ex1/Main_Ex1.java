package Ex1;

import java.util.Scanner;

public class Main_Ex1 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
				
		Aviao LATAM = new Aviao();
		Carro Golf = new Carro();
		
		System.out.println("Entre com a descri��o, capacidade e horas de voo do avi�o: ");
		LATAM.setDescricao(ler.next());
		LATAM.setCapacidade(ler.nextInt());
		LATAM.setHoras(ler.nextInt());
		
		System.out.println("Entre com a descri��o, capacidade e quilometragem do carro: ");
		Golf.setDescricao(ler.next());
		Golf.setCapacidade(ler.nextInt());
		Golf.setQuilometragem(ler.nextDouble());
		
		System.out.printf("\nCarro - \nDescri��o - %s\nCapacidade - %d\nQuilometragem - %.2f\n",
				Golf.getDescricao(),
				Golf.getCapacidade(),
				Golf.getQuilometragem());
		
		System.out.printf("\nAvi�o - \nDescri��o - %s\nCapacidade - %d\nHoras - %d\n",
				LATAM.getDescricao(),
				LATAM.getCapacidade(),
				LATAM.getHoras());
		
		ler.close();

	}

}
