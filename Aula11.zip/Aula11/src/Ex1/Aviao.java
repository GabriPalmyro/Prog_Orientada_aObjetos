package Ex1;

public class Aviao extends MeioTransporte {

	private int horas;

	public int getHoras() {
		return horas;
	}

	public void setHoras(int horas) {
		this.horas = horas;
	}
	
	
}
