package Ex1;

public class Carro extends MeioTransporte{
	
	private double quilometragem;

	public double getQuilometragem() {
		return quilometragem;
	}

	public void setQuilometragem(double quilometragem) {
		this.quilometragem = quilometragem;
	}

}
