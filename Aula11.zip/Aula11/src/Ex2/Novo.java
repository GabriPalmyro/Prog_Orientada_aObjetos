package Ex2;

public class Novo extends Imovel
{
	
	public double adicional(double ad)
	{
		return this.getPreco() + ad; 
	}
	
	public void impressao()
	{
		System.out.printf("O apartamento novo na %s est� saindo por %.2f\n", 
				this.getEndereco(), 
				this.getPreco());
	}
	
}
