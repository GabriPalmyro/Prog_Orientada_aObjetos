package Ex2;

public class Velho extends Imovel
{
	public double desconto(double ad)
	{
		return this.getPreco() - ad; 
	}
	
	public void impressao()
	{
		System.out.printf("O apartamento velho na %s est� saindo por %.2f\n", 
				this.getEndereco(), 
				this.getPreco());
	}
}
