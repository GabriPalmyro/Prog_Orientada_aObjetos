package Ex2;

import java.util.Scanner;

public class Main_Ex2 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Novo ApN = new Novo();
		Velho ApV = new Velho();
		
		System.out.println("Entre com o endere�o, o pre�o e o adicional do apartamento novo: ");
		ApN.setEndereco(ler.nextLine());
		ApN.setPreco(ler.nextDouble());
		ApN.setPreco(ApN.adicional(ler.nextDouble()));
		
		ler.nextLine();
		
		System.out.println("Entre com o endere�o, o pre�o e o desconto do apartamento velho: ");
		ApV.setEndereco(ler.nextLine());
		ApV.setPreco(ler.nextDouble());
		ApV.setPreco(ApV.desconto(ler.nextDouble()));
		
		ApN.impressao();
		ApV.impressao();
		
		ler.close();
	}

}
