package Ex6;

public class Aluno {
	
	String codigo;
	String nome;
	double nota1;
	double nota2;
	double media;
	int aprovado;
	
	public Aluno()
	{
		
	}
	
	public Aluno(String codigo, String nome, double nota1, double nota2)
	{
		this.codigo = codigo;
		this.nome 	= nome;
		this.nota1	= nota1;
		this.nota2 	= nota2;
	}
	
	void mediaArit()
	{
		this.media = (nota1+nota2)/2;
	}
	
	String verificaAprov()
	{
		String texto = "";
		
		if(media >= 6.00)
		{
			texto = "O aluno "+nome+" est� APROVADO com media "+this.media+"! BOAS FESTAS!\n";
			this.aprovado = 1;
		} else if(media < 6){
			texto = "O aluno "+nome+" est� REPROVADO com media "+this.media + "\n";
			this.aprovado = 0;
		}
		
		return texto;
	}
	
	String dados()
	{	
		String texto = "";
		
		if(this.aprovado == 1)
		{
			texto = "O aluno " + this.nome 
					+ ", de cod = " + this.codigo 
					+" possui m�dia igual a " 
					+ this.media + " portanto est� APROVADO!\n";
		} else {
			texto = "O aluno " + this.nome 
					+ ", de cod = " + this.codigo 
					+" possui m�dia igual a " 
					+ this.media + " portanto est� REPROVADO!\n";
		}
		
		return texto;
	}
	
}
