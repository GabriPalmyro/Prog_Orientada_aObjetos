package Ex6;

import java.util.Scanner;

public class Main_Ex6 {

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		
		String nome1 = "Gabriel", nome2= "Livia";
		String cod1 = "001", cod2 = "002";
		double nota1_1 = 9.0, nota1_2 = 8.5;
		double nota2_1 = 5.0, nota2_2 = 6.0;
		
		
		Aluno gabriel = new Aluno(cod1, nome1, nota1_1, nota1_2);
		
		Aluno livia = new Aluno();
		livia.nome = nome2;
		livia.codigo = cod2;
		livia.nota2 = nota2_1;
		livia.nota1 = nota2_2;

		gabriel.mediaArit();
		livia.mediaArit();
		
		System.out.printf("%s%s", gabriel.verificaAprov(), livia.verificaAprov());
		
		if(gabriel.aprovado == 1)
		{
			System.out.printf("\n%s", gabriel.dados());
		}
		
		if(livia.aprovado == 1)
		{
			System.out.printf("%s", livia.dados());
		}
		
		
		ler.close();


	}

}
