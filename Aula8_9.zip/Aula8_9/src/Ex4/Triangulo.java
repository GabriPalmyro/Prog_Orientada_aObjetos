package Ex4;

public class Triangulo {
	
	double base;
	double altura;
	
	public Triangulo(double altura, double base)
	{
		this.altura = altura;
		this.base = base;
	}
	
	double area()
	{
		return (base * altura) / 2;
	}

}
