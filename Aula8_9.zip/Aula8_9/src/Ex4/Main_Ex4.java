package Ex4;

import java.util.Scanner;

public class Main_Ex4 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		double base   = ler.nextDouble();
		double altura = ler.nextDouble();
		
		Triangulo triangulo = new Triangulo(altura, base);
		
		System.out.printf("A area desse triangulo � de %.2f\n", triangulo.area());
		
		ler.close();

	}

}
