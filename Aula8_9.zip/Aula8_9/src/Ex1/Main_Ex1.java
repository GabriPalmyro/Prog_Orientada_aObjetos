package Ex1;

import java.util.Scanner;

public class Main_Ex1 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Classe_Ex1 quad = new Classe_Ex1();
		
		int a = ler.nextInt();
		int b = ler.nextInt();
		
		System.out.printf("Fun��o 1 - %d\nFun��o 2 - %d\n", quad.quadrado(a), quad.quadrado(a, b));
		
		ler.close();

	}

}
