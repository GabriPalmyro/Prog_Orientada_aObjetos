package Ex1;

public class Classe_Ex1 {
	
	public int quadrado(int a)
	{
		return a*a;
	}
	
	public int quadrado(int a, int b)
	{
		int soma = 0;
		for(int i = 0; i < b; i++)
		{
			soma = soma + (a*a);
		}
		return soma;
	}
	
}
