package Ex2;

import java.util.Scanner;

public class Main_Ex2 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Medias media = new Medias();
		
		double nota1 = ler.nextDouble();
		double peso1 = ler.nextDouble();
		double nota2 = ler.nextDouble();
		double peso2 = ler.nextDouble();
		
		System.out.printf("Media 1 - %.2f\nMedia 2 - %.2f\n", 
				media.calcularMedia(nota1, nota2),
				media.calcularMedia(nota1, nota2, peso1, peso2));
		
		ler.close();

	}

}


