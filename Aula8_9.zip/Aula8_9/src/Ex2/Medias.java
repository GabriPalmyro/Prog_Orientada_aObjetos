package Ex2;

public class Medias {
	
	double calcularMedia(double nota1, double nota2)
	{
		double media = (nota1 + nota2) / 2;
		return media;
	}
	
	double calcularMedia(double nota1, double nota2, double peso1, double peso2)
	{
		double media = ((nota1*peso1)+(nota2*peso2)/2);
		return media;
	}
	
}
