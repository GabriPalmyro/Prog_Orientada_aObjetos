package Ex3;

public class Gerente {
	
	double salario;
	
	public Gerente(double salario)
	{
		this.salario = salario;
	}
	
	void AumentaSalario()
	{
		this.salario = this.salario * 1.10;
	}
	
	void AumentaSalario(double taxa)
	{
		this.salario = this.salario * (1+(taxa/100));
	}
	
}
