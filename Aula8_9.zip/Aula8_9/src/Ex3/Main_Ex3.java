package Ex3;

import java.util.Scanner;

public class Main_Ex3 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		double salario = ler.nextDouble();
		double taxa = ler.nextDouble();
			
		Gerente gerente = new Gerente(salario);
		
		int op = ler.nextInt();

		if(op == 1){
			
			gerente.AumentaSalario(taxa);
			System.out.printf("Salario com aumento da taxa %.2f\n", gerente.salario);
			
		}
		else if(op == 0) {
			
			gerente.AumentaSalario();
			System.out.printf("Salario com aumento de 10(porcento) %.2f\n", gerente.salario);
			
		}
		
		
		ler.close();

	}

}