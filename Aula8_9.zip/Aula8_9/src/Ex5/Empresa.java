package Ex5;

public class Empresa {
	
	String nome;
	String endereco;
	String cidade;
	String estado;
	Double ValorPatri;
	int quantFunc;
	
	public Empresa()
	{
		
	}
	
	
	public Empresa(String nome, String endereco, String cidade, String estado, Double ValorPatri, int quantFunc)
	{
		this.nome = nome;
		this.endereco = endereco;
		this.cidade = cidade;
		this.estado = estado;
		this.ValorPatri = ValorPatri;
		this.quantFunc = quantFunc;
	}
	
	String imprime()
	{
		String texto = "A empresa " + this.nome 
				+ " localizada em " + this.endereco 
				+ " - " + this.estado + " possui R$" 
				+ this.ValorPatri + " de valor patrimonial com um total de " 
				+ this.quantFunc + " funcion�rios\n";
		
		return texto;
	}

}
