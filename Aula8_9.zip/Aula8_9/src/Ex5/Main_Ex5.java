package Ex5;

import java.util.Scanner;

public class Main_Ex5 {
	
	static int maiorEmp(Empresa emp1, Empresa emp2)
	{
		if(emp1.ValorPatri > emp2.ValorPatri)
		{
			return 1;
		} else 
		{
			return 0;
		}
	}

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		String nomeEmp1 = "Inova Tech";
		String endEmp1 	= "Av Interlagos";
		String cidEmp1 	= "S�o Paulo";
		String estEmp1 	= "SP";
		Double vPEmp1 	= 1500000.0;
		int qFuncEmp1 	= 12;
		
		String nomeEmp2 = "Einstein Brain";
		String endEmp2 	= "Av Berrini";
		String cidEmp2 	= "S�o Paulo";
		String estEmp2 	= "SP";
		Double vPEmp2 	= 1800000.0;
		int qFuncEmp2 	= 6;
		
		Empresa Inova = new Empresa();
		
		Inova = new Empresa(nomeEmp1, endEmp1, cidEmp1, estEmp1, vPEmp1, qFuncEmp1);
		
		Empresa Einstein = new Empresa();
		
		Einstein = new Empresa(nomeEmp2, endEmp2, cidEmp2, estEmp2, vPEmp2, qFuncEmp2);
		
		System.out.printf("%s\n%s\n", Inova.imprime(), Einstein.imprime());
		
		if(maiorEmp(Inova, Einstein) == 1)
		{
			System.out.printf("Empresa Inova Tech possui maior valor patrimonial\n");
		} else
		{
			System.out.printf("Empresa Einstein Brain possui maior valor patrimonial\n");
		}
		
		
		ler.close();

	}

}
