package Ex3;

public class Cliente extends Pessoa{
	
	private double valorDivida;
	private int anoNascim;
	
	public Cliente() {}
	
	public Cliente(String nome, int idade, String sexo, int anoN, double vD) {
	
		this.setNome(nome);
		this.setIdade(idade);
		this.setSexo(sexo);
		this.valorDivida = vD;
		this.anoNascim = anoN;
	}
	
	
	public double getValorDivida() {
		return valorDivida;
	}
	public void setValorDivida(double valorDivida) {
		this.valorDivida = valorDivida;
	}
	public int getAnoNascim() {
		return anoNascim;
	}
	public void setAnoNascim(int anoNascim) {
		this.anoNascim = anoNascim;
	}
	
	public String printDados() {
		return "Nome: "+super.getNome()
		+"\nIdade: "+super.getIdade()
		+"\nValor da d�vida: "+valorDivida
		+"\nAno nascimento: "+anoNascim;
	}

}
