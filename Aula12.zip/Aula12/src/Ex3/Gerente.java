package Ex3;

public class Gerente extends Empregado{
	
	private String nomeGerencia;

	public Gerente() {}
	
	public Gerente(String nome, int idade, String sexo, double salario) {
		this.setNome(nome);
		this.setIdade(idade);
		this.setSexo(sexo);
		this.setSalario(salario);
	}
	
	public String getNomeGerencia() {
		return nomeGerencia;
	}

	public void setNomeGerencia(String nomeGerencia) {
		this.nomeGerencia = nomeGerencia;
	}
	
	public String printDados() {
		return "Nome: "+super.getNome()
		+"\nIdade: "+super.getIdade()
		+"\nMatricula: "+super.getMatricula()
		+"\nNome gerencia: "+nomeGerencia
		+"\nValor do INSS: "+super.valorInss();
	}

}
