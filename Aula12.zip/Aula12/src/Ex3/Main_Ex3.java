package Ex3;

import java.util.Scanner;

public class Main_Ex3 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Bem vindo a empresa IF!");
		Gerente Gabriel = new Gerente("Gabriel", 25, "M", 20000.00);
		Gabriel.setMatricula("101");
		Gabriel.setNomeGerencia("Lucas");
	
		
		Vendedor Carlos = new Vendedor("Carlos", 22, "M", 10000.00);
		Carlos.setMatricula("102");
		Carlos.setValorVendas(5000);
		Carlos.setQntVendas(35);
		
		
		Cliente Pedro = new Cliente("Pedro", 20, "M", 500, 2001);
		
		
		System.out.printf("Gerente - \n%s\n\nVendedor - \n%s\n\nCliente - \n%s\n", 
		Gabriel.printDados(),
		Carlos.printDados(),	
		Pedro.printDados());
		
		
		ler.close();

	}

}
