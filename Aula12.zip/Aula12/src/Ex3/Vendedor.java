package Ex3;

public class Vendedor extends Empregado{
	
	private double valorVendas;
	private int qntVendas;
	
	public Vendedor() {}
	
	public Vendedor(String nome, int idade, String sexo, double salario) {
		this.setNome(nome);
		this.setIdade(idade);
		this.setSexo(sexo);
		this.setSalario(salario);
	}
	
	public double getValorVendas() {
		return valorVendas;
	}
	public void setValorVendas(double valorVendas) {
		this.valorVendas = valorVendas;
	}
	public int getQntVendas() {
		return qntVendas;
	}
	public void setQntVendas(int qntVendas) {
		this.qntVendas = qntVendas;
	}
	
	public String printDados() {
		return "Nome: "+super.getNome()
		+"\nSal�rio: "+super.getSalario()
		+"\nValor de vendas: "+valorVendas
		+"\nQuantidade de vendas: "+qntVendas;
	}

}
