package Ex3;

public class Empregado extends Pessoa {

	private double salario;
	private String matricula;
	
	public Empregado() {}
	
	public Empregado(String nome, int idade, String sexo, double salario) {
		this.setNome(nome);
		this.setIdade(idade);
		this.setSexo(sexo);
		this.salario = salario;
	}
	
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public double valorInss(){
		return salario * 0.11;
	}
}
