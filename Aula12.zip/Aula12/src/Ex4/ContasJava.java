package Ex4;

import java.util.Scanner;

public class ContasJava {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);	
		
		System.out.println("Bem vindo ao banco IFSP!");
		ContaPoupanca Gabriel = new ContaPoupanca();
		System.out.println("Nome: ");
		Gabriel.setCliente(ler.next());
		System.out.println("N�mero de conta: ");
		Gabriel.setNum_conta(ler.nextInt());
		System.out.println("Saldo: ");
		Gabriel.setSaldo(ler.nextDouble());
		System.out.println("Dia de rendimento: ");
		Gabriel.setDiaDeRendimento(ler.nextInt());
		
		ContaEspecial Carlos = new ContaEspecial();
		System.out.println("Nome: ");
		Carlos.setCliente(ler.next());
		System.out.println("N�mero de conta: ");
		Carlos.setNum_conta(ler.nextInt());
		System.out.println("Saldo: ");
		Carlos.setSaldo(ler.nextDouble());
		System.out.println("Limite: ");
		Carlos.setLimite(ler.nextDouble());
		
		System.out.println("Valor a sacar de conta poupan�a: ");
		Gabriel.sacar(ler.nextDouble());
		
		System.out.println("Valor a sacar de conta especial: ");
		Carlos.sacar(ler.nextDouble());
		
		Gabriel.calcularNovoSaldo(5);
		
		System.out.printf("Saldo dos clientes de conta poupan�a com rendimento\nGabriel - %s\n", 
				Gabriel.imprimirSaldo());
		
		System.out.println("\nConta poupan�a:\nNome: "+Gabriel.getCliente()
		+"\nN�mero de conta: "+Gabriel.getNum_conta()
		+"\nSaldo: "+Gabriel.getSaldo());
		
		System.out.println("\nConta especial:\nNome: "+Carlos.getCliente()
		+"\nN�mero de conta: "+Carlos.getNum_conta()
		+"\nSaldo: "+Carlos.getSaldo());
		
		ler.close();
	}

}
