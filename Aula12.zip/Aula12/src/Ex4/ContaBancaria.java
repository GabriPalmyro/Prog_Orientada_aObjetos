package Ex4;

public class ContaBancaria {

	private String cliente;
	private int num_conta;
	private double saldo;
	
	public ContaBancaria() {}
	
	public ContaBancaria(String cliente, int num_conta, double saldo) {
		this.cliente = cliente;
		this.num_conta = num_conta;
		this.saldo = saldo;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public int getNum_conta() {
		return num_conta;
	}

	public void setNum_conta(int num_conta) {
		this.num_conta = num_conta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public void sacar(double ret) {
		if(saldo - ret < 0)
		{
			System.out.println("N�o foi poss�vel sacar. Saldo final menor que 0.\n");
		} else {
			this.saldo = saldo - ret;
		}
	}
	
	public void depositar(double dep) {
		this.saldo = saldo + dep;
	}
	
	public String imprimirSaldo() {
		return "Saldo do cliente "+cliente+" = R$"+saldo;
	}
	
}
