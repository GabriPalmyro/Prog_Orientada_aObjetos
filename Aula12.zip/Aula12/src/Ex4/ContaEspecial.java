package Ex4;

public class ContaEspecial extends ContaBancaria{

	private double limite;
	
	public ContaEspecial() {}
	
	public ContaEspecial(String cliente, int num_conta, double saldo, double limite) {
		this.setCliente(cliente);
		this.setNum_conta(num_conta);
		this.setSaldo(saldo);
		this.limite = limite;
	}

	public double getLimite() {
		return limite;
	}

	public void setLimite(double limite) {
		this.limite = limite;
	}
	
	public void sacar(double ret) {
		if(super.getSaldo() - ret < limite*-1) {
			System.out.println("N�o foi poss�vel sacar. Saldo final menor que limite.\n");
		} else {
			this.setSaldo(super.getSaldo() - ret);
		}
	}
	
}
