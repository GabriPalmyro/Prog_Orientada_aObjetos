package Ex4;

public class ContaPoupanca extends ContaBancaria{

	private int diaDeRendimento;

	public ContaPoupanca() {}
	
	public ContaPoupanca(String cliente, int num_conta, double saldo, int dR) {
		this.setCliente(cliente);
		this.setNum_conta(num_conta);
		this.setSaldo(saldo);
		this.diaDeRendimento = dR;
	}
	
	public int getDiaDeRendimento() {
		return diaDeRendimento;
	}

	public void setDiaDeRendimento(int diaDeRendimento) {
		this.diaDeRendimento = diaDeRendimento;
	}
	
	public void calcularNovoSaldo(double rend) {
		this.setSaldo(super.getSaldo() + (super.getSaldo() * (rend/100)));
	}
	
}
