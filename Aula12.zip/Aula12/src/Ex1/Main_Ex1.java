package Ex1;

import java.util.Scanner;

public class Main_Ex1 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		Fornecedor JBS = new Fornecedor();
		System.out.println("Entre com o nome, o endere�o, o telefone do fornecedor: ");
		JBS.setNome(ler.next());
		JBS.setEndereco(ler.next());
		JBS.telefone = ler.next();
		System.out.println("Diga o valor de cr�dito e a divida dessa empresa: ");
		JBS.setValorCredito(ler.nextDouble());
		JBS.setValorDivida(ler.nextDouble());

		System.out.printf("%s cujo saldo � de R$%.2f\n", JBS.imprimirDados(), JBS.obterSaldo());
		
		
		ler.close();

	}

}
