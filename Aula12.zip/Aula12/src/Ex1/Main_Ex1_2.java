package Ex1;

import java.util.Scanner;

public class Main_Ex1_2 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Empregado Junior = new Empregado();
		
		System.out.println("Entre com o nome, o endere�o, o telefone do empregado: ");
		Junior.setNome(ler.next());
		Junior.setEndereco(ler.next());
		Junior.telefone = ler.next();
		System.out.println("Agora insira o c�digo do setor do empregado juntamente com seu sal�rio base e sua porcentagem de impostos: : ");
		Junior.setCodigoSetor(ler.nextInt());
		Junior.setSalarioBase(ler.nextDouble());
		Junior.setImpostos(ler.nextDouble());
		
		System.out.printf("%s possui sal�rio final de R$%.2f\n", Junior.imprimirDados(), Junior.CalcularSalario());
		
		ler.close();
		

	}

}
