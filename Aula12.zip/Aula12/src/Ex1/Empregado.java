package Ex1;

public class Empregado extends Pessoa {

	private int codigoSetor;
	private double salarioBase;
	private double impostos;
	
	public Empregado()
	{
		
	}

	public Empregado(int codigoSet, double SalB, double Imp)
	{
		this.codigoSetor = codigoSet;
		this.salarioBase = SalB;
		this.impostos = Imp;
	}

	public int getCodigoSetor() {
		return codigoSetor;
	}

	public void setCodigoSetor(int codigoSetor) {
		this.codigoSetor = codigoSetor;
	}

	public double getSalarioBase() {
		return salarioBase;
	}

	public void setSalarioBase(double salarioBase) {
		this.salarioBase = salarioBase;
	}

	public double getImpostos() {
		return impostos;
	}

	public void setImpostos(double impostos) {
		this.impostos = impostos;
	}
	
	double CalcularSalario()
	{
		return salarioBase - (salarioBase*impostos/100);
	}
	
	public String imprimirDados()
	{
		return "\nNome, "+getNome()
		+", residente em "+getEndereco()
		+", cujo telefone � ("+getTelefone()+")";
	}
	
}
