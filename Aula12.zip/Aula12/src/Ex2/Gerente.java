package Ex2;

public class Gerente extends Empregado{

	private double gratificacao;
	
	public Gerente(String nome, double salario, double grat) {
		super(nome, salario);
		this.gratificacao = grat;
	}
	
	public String ImprimeDados()
	{
		return "Nome: "+super.getNome()+"\nSalario: "+SalarioFixo+"\n";
	}
	
	public double CalculaSalario()
	{
		return super.getSalarioFixo() + gratificacao;
	}

	public double getGratificao() {
		return gratificacao;
	}

	public void setGratificao(double gratificao) {
		this.gratificacao = gratificao;
	}
}
