package Ex2;

import java.util.Scanner;

public class Main_Ex2 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Entre com o nome e o sal�rio do empregado: ");
		Empregado Lucio = new Empregado(ler.next(), ler.nextDouble());
		System.out.println("Entre com o nome e o sal�rio e a gratifica��o do gerente do empregado: ");
		Gerente Mario = new Gerente(ler.next(), ler.nextDouble(), ler.nextDouble());
		
		System.out.printf("Sal�rio do empregado %s � de R$%.2f\n"
				+ "Sal�rio do gerente %s � de R$%.2f", 
				Lucio.getNome(), Lucio.getSalarioFixo(),
				Mario.getNome(), Mario.CalculaSalario());

		ler.close();
		
	}

}
