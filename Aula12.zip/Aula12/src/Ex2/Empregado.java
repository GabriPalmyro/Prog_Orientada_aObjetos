package Ex2;

public class Empregado {
	
	private String nome;
	protected double SalarioFixo;
	
	public Empregado(String nome, double salario)
	{
		this.nome = nome;
		this.SalarioFixo = salario;
	}
	
	public String ImprimeDados()
	{
		return "Nome: "+nome+"\nSalario: "+SalarioFixo;
	}

	public double CalculaSalario() 
	{
		return SalarioFixo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalarioFixo() {
		return SalarioFixo;
	}

	public void setSalarioFixo(double salarioFixo) {
		SalarioFixo = salarioFixo;
	}
	
}
